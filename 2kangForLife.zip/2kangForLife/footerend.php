<!DOCTYPE html>
<html>
<head>
	
<body>

<!-- Footer-->
<section class="footer">
  <div class="container">
    <h3>2Kang For Life</h3>
    <div class="wrapper">
      <ul class="social-icons icon-circle icon-zoom list-unstyled list-inline"> 
        <li> <a href="#"><i class="fab fa-facebook-f"></i></a></li> 
        <li> <a href="#"><i class="fab fa-twitter"></i></a></li>
      </ul>
    </div>
    <div class="copyright">
     <p>© 2019 Proyek1 | Berliana - Ilmiyatus - Tyka </p>
   </div>
 </div>
</section>
<!-- /Footer-->
</body>
</html>